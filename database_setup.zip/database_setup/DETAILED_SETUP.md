# CTAS Database Infrastructure - Detailed Setup Guide

## Overview

CTAS requires a highly scalable, multi-database architecture designed for real-time threat analysis and response. Each database component serves a specific purpose while maintaining high availability and data consistency.

## Core Components

### 1. MongoDB (v6.0) - Operational Data Store
- **Purpose**: Handles operational data, user management, and audit logs
- **Configuration**: 3-node replica set with automatic failover
- **Storage**: 50GB per node, expandable
- **Key Features**:
  - Document-based storage for flexible schema evolution
  - Sharding support for horizontal scaling
  - Change streams for real-time data updates
  - Time-series collections for metrics

### 2. Neo4j (v5.15 Enterprise) - Graph Relationships
- **Purpose**: Manages threat actor relationships and attack patterns
- **Configuration**: 3-node cluster with read replicas
- **Storage**: 100GB per node, expandable
- **Key Features**:
  - APOC plugins for advanced graph operations
  - Graph Data Science library support
  - Causal clustering for consistency
  - Bolt protocol for efficient communication

### 3. Apache Kafka (v7.5) - Event Streaming
- **Purpose**: Real-time event streaming and data pipeline
- **Configuration**: 3-broker cluster with replication
- **Storage**: 50GB per broker, expandable
- **Key Features**:
  - Multi-topic architecture for event segregation
  - Exactly-once semantics
  - Stream processing capabilities
  - Schema registry integration

### 4. PostgreSQL (v14 with PostGIS) - Geospatial Data
- **Purpose**: Location-based data and spatial analysis
- **Configuration**: 3-node cluster with streaming replication
- **Storage**: 50GB per node, expandable
- **Key Features**:
  - PostGIS extension for spatial operations
  - Partitioning for large datasets
  - Full-text search capabilities
  - Advanced indexing strategies

### 5. Elasticsearch (v8.11) - Search and Analytics
- **Purpose**: Full-text search and log aggregation
- **Configuration**: 3-node cluster with dedicated master nodes
- **Storage**: 100GB per node, expandable
- **Key Features**:
  - Advanced text analysis
  - Aggregation framework
  - Machine learning capabilities
  - Real-time search and analytics

## Data Flow Architecture

```mermaid
graph TD
    A[Event Sources] -->|Raw Events| B[Kafka]
    B -->|Enrichment| C[Stream Processing]
    C -->|Processed Events| D[MongoDB]
    C -->|Relationships| E[Neo4j]
    C -->|Spatial Data| F[PostgreSQL]
    C -->|Search Index| G[Elasticsearch]
    
    H[Applications] -->|Queries| I[API Layer]
    I -->|CRUD| D
    I -->|Graph Queries| E
    I -->|Spatial Queries| F
    I -->|Search| G
```

## Implementation Details

### 1. Docker Compose Setup (Development)
```yaml
version: '3.8'
services:
  mongodb:
    image: mongo:6.0
    # Configuration in docker-compose.yml
  neo4j:
    image: neo4j:5.15-enterprise
    # Configuration in docker-compose.yml
  kafka:
    image: confluentinc/cp-kafka:7.5.0
    # Configuration in docker-compose.yml
  postgres:
    image: postgis/postgis:14-3.2
    # Configuration in docker-compose.yml
  elasticsearch:
    image: elasticsearch:8.11.0
    # Configuration in docker-compose.yml
```

### 2. Kubernetes Deployment (Production)
```yaml
# StatefulSet examples in k8s/ directory
- mongodb.yaml
- neo4j.yaml
- kafka.yaml
- postgres.yaml
- elasticsearch.yaml
```

## Extensibility Points

### 1. Data Model Extensions
- MongoDB: Flexible schema allows adding new fields
- Neo4j: New node labels and relationship types
- PostgreSQL: Additional tables and spatial data types
- Elasticsearch: Dynamic mapping for new fields

### 2. Scaling Options
- Vertical: Increase resources per node
- Horizontal: Add nodes to clusters
- Storage: Expand volume claims
- Compute: Adjust CPU/memory limits

### 3. Integration Points
- Kafka Connect for external systems
- REST APIs for each database
- GraphQL integration possible
- Custom connectors support

### 4. Monitoring Integration
- Prometheus metrics
- Grafana dashboards
- Custom health checks
- Log aggregation

## Security Considerations

### 1. Authentication
```yaml
# Example Secret Configuration
apiVersion: v1
kind: Secret
metadata:
  name: ctas-secrets
type: Opaque
data:
  mongodb-password: base64_encoded_password
  neo4j-password: base64_encoded_password
  postgres-password: base64_encoded_password
```

### 2. Network Security
- Internal service communication
- TLS encryption
- Network policies
- Service mesh integration

### 3. Access Control
- Role-based access (RBAC)
- Resource quotas
- Pod security policies
- Audit logging

## Backup Strategy

### 1. MongoDB Backup
```bash
# Automated backup script
mongodump --uri="mongodb://user:pass@host:port" --out=/backup/mongo
```

### 2. Neo4j Backup
```bash
# Enterprise backup
neo4j-admin backup --backup-dir=/backup/neo4j --name=full
```

### 3. PostgreSQL Backup
```bash
# Continuous archiving
pg_basebackup -D /backup/postgres -Ft -x -P
```

### 4. Elasticsearch Backup
```bash
# Snapshot repository
PUT /_snapshot/backup
{
  "type": "fs",
  "settings": {
    "location": "/backup/elasticsearch"
  }
}
```

## Performance Tuning

### 1. MongoDB Optimization
```javascript
// Index Strategy
db.collection.createIndex({ field: 1 }, { background: true })
```

### 2. Neo4j Optimization
```cypher
// Memory Configuration
dbms.memory.heap.initial_size=4G
dbms.memory.heap.max_size=8G
```

### 3. Kafka Optimization
```properties
# Broker Configuration
num.io.threads=8
num.network.threads=3
```

### 4. PostgreSQL Optimization
```sql
-- Configuration
ALTER SYSTEM SET shared_buffers = '4GB';
ALTER SYSTEM SET effective_cache_size = '12GB';
```

## Monitoring Setup

### 1. Health Checks
```yaml
livenessProbe:
  exec:
    command:
    - /health/check.sh
  initialDelaySeconds: 30
  periodSeconds: 10
```

### 2. Resource Monitoring
```yaml
resources:
  limits:
    cpu: "4"
    memory: "16Gi"
  requests:
    cpu: "2"
    memory: "8Gi"
```

## Development Workflow

1. Local Development
```bash
# Start development environment
docker-compose up -d

# Verify services
docker-compose ps
```

2. Testing
```bash
# Run integration tests
./scripts/test-integration.sh

# Check connectivity
./scripts/verify-connections.sh
```

3. Production Deployment
```bash
# Deploy to Kubernetes
kubectl apply -f k8s/

# Verify deployment
kubectl get pods
```

## Maintenance Procedures

### 1. Upgrades
- Rolling updates for zero downtime
- Version compatibility checks
- Rollback procedures
- Data migration plans

### 2. Monitoring
- Resource utilization
- Performance metrics
- Error rates
- Backup status

### 3. Troubleshooting
- Log analysis
- Health check verification
- Connection testing
- Performance profiling