# Database Developer Instructions

## Infrastructure Setup Required

We need a multi-database infrastructure deployed using Docker Compose and Kubernetes for a high-availability production environment. The core components are:

1. **MongoDB (v6.0)**
   - 3-node replica set
   - 50GB storage per node
   - Authentication enabled
   - Used for: Operational data, user data, audit logs

2. **Neo4j (v5.15 Enterprise)**
   - 3-node cluster
   - 100GB storage per node
   - APOC plugins enabled
   - Used for: Graph relationships, attack patterns

3. **Apache Kafka (v7.5)**
   - 3-broker cluster
   - 50GB storage per broker
   - Used for: Event streaming, real-time data pipeline

4. **PostgreSQL (v14 with PostGIS)**
   - 3-node cluster
   - 50GB storage per node
   - Used for: Geospatial data

5. **Elasticsearch (v8.11)**
   - 3-node cluster
   - 100GB storage per node
   - Used for: Full-text search, log aggregation

## Development Requirements

1. Create Docker Compose setup for local development
2. Implement Kubernetes manifests for production deployment
3. Configure high availability and replication
4. Set up monitoring and health checks
5. Implement backup procedures
6. Configure security (authentication, encryption)

All configuration files and schemas are provided in the `/schemas` directory. The application will connect to these databases using standard connection strings - no application code access is needed for the initial setup.