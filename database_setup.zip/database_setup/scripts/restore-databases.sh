#!/bin/bash

# Exit on error
set -e

# Load environment variables
source .env

# Check if backup file is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <backup_file.tar.gz>"
    exit 1
fi

BACKUP_FILE=$1
TEMP_DIR="restore_temp"

# Extract backup
mkdir -p "$TEMP_DIR"
tar -xzf "$BACKUP_FILE" -C "$TEMP_DIR"

# Restore MongoDB
mongorestore --uri "$MONGODB_URI" --dir "$TEMP_DIR/mongodb"

# Restore Neo4j
neo4j-admin load --from="$TEMP_DIR/neo4j.dump" --database=neo4j --force

# Restore PostgreSQL
PGPASSWORD=${POSTGRES_PASSWORD} psql -h postgres-0.postgres -U ctas_user ctas_geospatial < "$TEMP_DIR/postgres.sql"

# Restore Elasticsearch
elasticdump \
  --input="$TEMP_DIR/elasticsearch.json" \
  --output=http://localhost:9200/ctas \
  --type=data

# Cleanup
rm -rf "$TEMP_DIR"

echo "Database restoration complete!"