#!/bin/bash

# Exit on error
set -e

# Load environment variables
source .env

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "CTAS Database Connection Verification"
echo "===================================="

# MongoDB Check
echo -n "Testing MongoDB connection... "
if mongosh --quiet --eval "db.adminCommand('ping')" mongodb://ctas_user:${MONGO_PASSWORD}@mongodb-0.mongodb:27017/admin?replicaSet=rs0 &>/dev/null; then
    echo -e "${GREEN}Connected${NC}"
else
    echo -e "${RED}Failed${NC}"
fi

# Neo4j Check
echo -n "Testing Neo4j connection... "
if cypher-shell -u neo4j -p ${NEO4J_PASSWORD} "RETURN 1;" &>/dev/null; then
    echo -e "${GREEN}Connected${NC}"
else
    echo -e "${RED}Failed${NC}"
fi

# PostgreSQL Check
echo -n "Testing PostgreSQL connection... "
if PGPASSWORD=${POSTGRES_PASSWORD} psql -h postgres-0.postgres -U ctas_user -d ctas_geospatial -c "SELECT 1;" &>/dev/null; then
    echo -e "${GREEN}Connected${NC}"
else
    echo -e "${RED}Failed${NC}"
fi

# Elasticsearch Check
echo -n "Testing Elasticsearch connection... "
if curl -s -u elastic:${ELASTIC_PASSWORD} http://elasticsearch-0.elasticsearch:9200/_cluster/health | grep -q 'status'; then
    echo -e "${GREEN}Connected${NC}"
else
    echo -e "${RED}Failed${NC}"
fi

# Kafka Check
echo -n "Testing Kafka connection... "
if kafka-broker-api-versions.sh --bootstrap-server kafka-0.kafka:9092 &>/dev/null; then
    echo -e "${GREEN}Connected${NC}"
else
    echo -e "${RED}Failed${NC}"
fi

echo "===================================="