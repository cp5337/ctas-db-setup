#!/bin/bash

# Exit on error
set -e

# Load environment variables
source .env

# Backup timestamp
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="backups/$TIMESTAMP"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Backup MongoDB
mongodump --uri "$MONGODB_URI" --out "$BACKUP_DIR/mongodb"

# Backup Neo4j
neo4j-admin dump --database=neo4j --to="$BACKUP_DIR/neo4j.dump"

# Backup PostgreSQL
PGPASSWORD=${POSTGRES_PASSWORD} pg_dump -h postgres-0.postgres -U ctas_user ctas_geospatial > "$BACKUP_DIR/postgres.sql"

# Backup Elasticsearch
elasticdump \
  --input=http://localhost:9200/ctas \
  --output="$BACKUP_DIR/elasticsearch.json" \
  --type=data

# Compress backups
tar -czf "$BACKUP_DIR.tar.gz" "$BACKUP_DIR"

# Upload to cloud storage (example using AWS S3)
aws s3 cp "$BACKUP_DIR.tar.gz" "s3://$S3_BUCKET/backups/"

# Cleanup
rm -rf "$BACKUP_DIR"
rm "$BACKUP_DIR.tar.gz"