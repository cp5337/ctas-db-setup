#!/bin/bash

# Exit on error
set -e

# Load environment variables
source .env

# Function to check service health
check_service() {
    local service=$1
    local endpoint=$2
    local check_command=$3
    
    echo -n "Checking $service... "
    if eval "$check_command"; then
        echo "OK"
        return 0
    else
        echo "FAILED"
        return 1
    fi
}

# MongoDB health check
check_service "MongoDB" \
    "mongodb://mongodb-0.mongodb:27017" \
    "mongosh --quiet --eval 'db.adminCommand(\"ping\")' mongodb://ctas_user:${MONGO_PASSWORD}@mongodb-0.mongodb:27017/admin"

# Neo4j health check
check_service "Neo4j" \
    "bolt://neo4j-0.neo4j:7687" \
    "cypher-shell -u neo4j -p ${NEO4J_PASSWORD} 'RETURN 1;'"

# PostgreSQL health check
check_service "PostgreSQL" \
    "postgres-0.postgres:5432" \
    "PGPASSWORD=${POSTGRES_PASSWORD} psql -h postgres-0.postgres -U ctas_user -d ctas_geospatial -c 'SELECT 1;'"

# Elasticsearch health check
check_service "Elasticsearch" \
    "http://elasticsearch-0.elasticsearch:9200" \
    "curl -s -u elastic:${ELASTIC_PASSWORD} http://elasticsearch-0.elasticsearch:9200/_cluster/health | grep -q 'status'"

# Kafka health check
check_service "Kafka" \
    "kafka-0.kafka:9092" \
    "kafka-topics.sh --bootstrap-server kafka-0.kafka:9092 --list"