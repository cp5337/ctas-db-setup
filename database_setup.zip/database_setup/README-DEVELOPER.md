## CTAS Database Developer Guide

### Quick Start

1. Clone the repository and navigate to the database setup directory:
```bash
cd database_setup
```

2. Copy and configure environment variables:
```bash
cp .env.example .env
# Edit .env with your desired passwords and configuration
```

3. Start the development environment:
```bash
docker-compose up -d
```

4. Verify the setup:
```bash
./scripts/verify-connections.sh
```

### Database Access

#### MongoDB
```javascript
// Connection string
mongodb://ctas_user:${MONGO_PASSWORD}@mongodb-0.mongodb:27017/ctas?replicaSet=rs0
```

#### Neo4j
```javascript
// Connection string
bolt://neo4j-0.neo4j:7687
```

#### PostgreSQL
```javascript
// Connection string
postgresql://ctas_user:${POSTGRES_PASSWORD}@postgres-0.postgres:5432/ctas_geospatial
```

### Development Workflow

1. Make changes to schemas in `/schemas/database/`
2. Test changes locally using Docker Compose
3. Run verification scripts
4. Submit changes for review

### Common Tasks

#### Adding a New Collection/Table
1. Update schema files
2. Run initialization scripts
3. Update indexes
4. Test queries

#### Backup/Restore
```bash
# Backup
./scripts/backup-databases.sh

# Restore
./scripts/restore-databases.sh backup_file.tar.gz
```

### Troubleshooting

If you encounter issues:
1. Check logs: `docker-compose logs [service]`
2. Run health checks: `./scripts/health-check.sh`
3. Verify connections: `./scripts/verify-connections.sh`

### Need Help?

- Review documentation in `/docs/database/`
- Check connection strings in `CONNECTION_STRINGS.md`
- Consult `DETAILED_SETUP.md` for advanced configuration