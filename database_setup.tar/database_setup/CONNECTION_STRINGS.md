# Database Connection Strings and Configuration

## MongoDB
```javascript
// Connection string format
mongodb://[username:password@]host1[:port1][,...hostN[:portN]][/[defaultauthdb][?options]]

// Example for replica set
const mongoUri = "mongodb://ctas_user:${MONGO_PASSWORD}@mongodb-0.mongodb:27017,mongodb-1.mongodb:27017,mongodb-2.mongodb:27017/ctas?replicaSet=rs0&authSource=admin";

// Connection options
const mongoOptions = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  retryWrites: true,
  w: 'majority',
  readPreference: 'primary',
  maxPoolSize: 50
};
```

## Neo4j
```javascript
// Connection string format
bolt://[username:password@]host[:port][?options]

// Example for cluster
const neo4jUri = "neo4j://neo4j-0.neo4j:7687,neo4j-1.neo4j:7687,neo4j-2.neo4j:7687";
const neo4jConfig = {
  username: "neo4j",
  password: "${NEO4J_PASSWORD}",
  database: "ctas",
  maxConnectionPoolSize: 100,
  connectionTimeout: 30000
};
```

## PostgreSQL
```javascript
// Connection string format
postgresql://[username:password@]host[:port][/database][?options]

// Example for cluster with PostGIS
const postgresUri = "postgresql://ctas_user:${POSTGRES_PASSWORD}@postgres-0.postgres:5432,postgres-1.postgres:5432,postgres-2.postgres:5432/ctas_geospatial";
const postgresConfig = {
  ssl: true,
  max: 20, // connection pool size
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000
};
```

## Elasticsearch
```javascript
// Connection configuration
const elasticsearchConfig = {
  node: [
    'http://elasticsearch-0.elasticsearch:9200',
    'http://elasticsearch-1.elasticsearch:9200',
    'http://elasticsearch-2.elasticsearch:9200'
  ],
  auth: {
    username: 'elastic',
    password: '${ELASTIC_PASSWORD}'
  },
  maxRetries: 5,
  requestTimeout: 30000
};
```

## Kafka
```javascript
// Broker configuration
const kafkaConfig = {
  clientId: 'ctas-client',
  brokers: [
    'kafka-0.kafka:9092',
    'kafka-1.kafka:9092',
    'kafka-2.kafka:9092'
  ],
  ssl: true,
  sasl: {
    mechanism: 'plain',
    username: '${KAFKA_USERNAME}',
    password: '${KAFKA_PASSWORD}'
  }
};
```

## Environment Variables
Create a `.env` file with these variables:
```bash
# MongoDB
MONGO_PASSWORD=your_mongodb_password
MONGO_REPLICA_SET=rs0

# Neo4j
NEO4J_PASSWORD=your_neo4j_password
NEO4J_DATABASE=ctas

# PostgreSQL
POSTGRES_PASSWORD=your_postgres_password
POSTGRES_DB=ctas_geospatial

# Elasticsearch
ELASTIC_PASSWORD=your_elasticsearch_password
ELASTIC_USERNAME=elastic

# Kafka
KAFKA_USERNAME=your_kafka_username
KAFKA_PASSWORD=your_kafka_password
```

## Health Check Endpoints
```bash
# MongoDB
mongodb-0.mongodb:27017/admin?ping=1

# Neo4j
bolt://neo4j-0.neo4j:7687

# PostgreSQL
postgres-0.postgres:5432/ctas_geospatial

# Elasticsearch
http://elasticsearch-0.elasticsearch:9200/_cluster/health

# Kafka
kafka-0.kafka:9092
```

## Testing Connections
Use the provided script to verify all connections:
```bash
./scripts/verify-connections.sh
```

This will test connectivity to all database services and report their status.