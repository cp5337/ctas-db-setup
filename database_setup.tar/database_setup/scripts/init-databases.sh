#!/bin/bash

# Exit on error
set -e

# Load environment variables
source .env

echo "Initializing CTAS Databases"
echo "=========================="

# Initialize MongoDB
echo "Setting up MongoDB..."
mongosh --quiet mongodb://ctas_user:${MONGO_PASSWORD}@mongodb-0.mongodb:27017/admin << EOF
rs.initiate({
  _id: "rs0",
  members: [
    { _id: 0, host: "mongodb-0.mongodb:27017" },
    { _id: 1, host: "mongodb-1.mongodb:27017" },
    { _id: 2, host: "mongodb-2.mongodb:27017" }
  ]
})
EOF

# Initialize Neo4j
echo "Setting up Neo4j..."
cypher-shell -u neo4j -p ${NEO4J_PASSWORD} < /schemas/database/neo4j/schema.cypher
cypher-shell -u neo4j -p ${NEO4J_PASSWORD} < /schemas/database/neo4j/pole_schema.cypher

# Initialize PostgreSQL with PostGIS
echo "Setting up PostgreSQL..."
PGPASSWORD=${POSTGRES_PASSWORD} psql -h postgres-0.postgres -U ctas_user -d ctas_geospatial << EOF
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;
CREATE EXTENSION IF NOT EXISTS fuzzystrmatch;
CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder;
EOF

# Initialize Elasticsearch
echo "Setting up Elasticsearch..."
curl -X PUT -u elastic:${ELASTIC_PASSWORD} "http://elasticsearch-0.elasticsearch:9200/_template/ctas_template" -H 'Content-Type: application/json' -d @/schemas/database/elasticsearch/template.json

# Initialize Kafka Topics
echo "Setting up Kafka topics..."
kafka-topics.sh --create --bootstrap-server kafka-0.kafka:9092 \
  --topic threat-events --partitions 12 --replication-factor 3

kafka-topics.sh --create --bootstrap-server kafka-0.kafka:9092 \
  --topic system-events --partitions 6 --replication-factor 3

kafka-topics.sh --create --bootstrap-server kafka-0.kafka:9092 \
  --topic task-events --partitions 6 --replication-factor 3

echo "=========================="
echo "Database initialization complete!"