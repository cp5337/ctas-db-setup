#!/bin/bash

# Wait for Kafka to be ready
until kafka-topics.sh --bootstrap-server kafka:9092 --list; do
  echo "Waiting for Kafka..."
  sleep 5
done

# Create topics with optimal configuration for CTAS
topics=(
  "threat-events:12:3"
  "system-events:6:3"
  "task-events:6:3"
  "metoc-data:6:3"
  "pole-updates:6:3"
)

for topic in "${topics[@]}"; do
  IFS=':' read -r name partitions replication <<< "$topic"
  
  echo "Creating topic: $name"
  kafka-topics.sh --create \
    --bootstrap-server kafka:9092 \
    --topic "$name" \
    --partitions "$partitions" \
    --replication-factor "$replication" \
    --config cleanup.policy=delete \
    --config retention.ms=604800000 \
    --config min.insync.replicas=2
done

# Set up Stream Processing
kafka-streams-application-reset.sh \
  --bootstrap-servers kafka:9092 \
  --application-id ctas-streams \
  --input-topics threat-events,system-events