# Database Initialization Scripts

This directory contains scripts for initializing each database component of CTAS.

## Scripts Overview

- `init-mongodb.js`: MongoDB initialization and indexes
- `init-neo4j.sh`: Neo4j schema and constraints
- `init-postgres.sql`: PostgreSQL/PostGIS setup
- `init-elasticsearch.json`: Elasticsearch mappings and settings
- `init-kafka-topics.sh`: Kafka topic creation and configuration

## Usage

These scripts are automatically executed when starting the databases via Docker Compose or Kubernetes. They handle:

1. Schema creation
2. Index setup
3. Initial data population
4. Security configuration

## Manual Execution

If needed, scripts can be run manually:

```bash
# MongoDB
mongosh < init-mongodb.js

# Neo4j
./init-neo4j.sh

# PostgreSQL
psql -f init-postgres.sql

# Elasticsearch
curl -X PUT -H "Content-Type: application/json" -d @init-elasticsearch.json ...

# Kafka
./init-kafka-topics.sh
```