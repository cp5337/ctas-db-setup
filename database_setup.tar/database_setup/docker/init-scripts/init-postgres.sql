-- Enable PostGIS extensions
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;
CREATE EXTENSION IF NOT EXISTS fuzzystrmatch;
CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder;

-- Create schemas
CREATE SCHEMA IF NOT EXISTS pole;
CREATE SCHEMA IF NOT EXISTS metoc;

-- Create POLE tables
CREATE TABLE pole.locations (
    id UUID PRIMARY KEY,
    name VARCHAR(255),
    type VARCHAR(50),
    coordinates GEOMETRY(Point, 4326),
    ndex_id VARCHAR(255),
    synaptic_hash VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE metoc.observations (
    id UUID PRIMARY KEY,
    location_id UUID REFERENCES pole.locations(id),
    temperature DECIMAL,
    humidity DECIMAL,
    wind_speed DECIMAL,
    wind_direction DECIMAL,
    precipitation DECIMAL,
    visibility DECIMAL,
    pressure DECIMAL,
    cloud_cover DECIMAL,
    sea_state DECIMAL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX locations_coordinates_idx ON pole.locations USING GIST (coordinates);
CREATE INDEX locations_synaptic_hash_idx ON pole.locations (synaptic_hash);
CREATE INDEX metoc_timestamp_idx ON metoc.observations (timestamp);
CREATE INDEX metoc_location_idx ON metoc.observations (location_id);

-- Create update trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_locations_updated_at
    BEFORE UPDATE ON pole.locations
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();